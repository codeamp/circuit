--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.4
-- Dumped by pg_dump version 11.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dex;
--
-- Name: dex; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE dex WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE dex OWNER TO postgres;

\connect dex

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: auth_code; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_code (id, client_id, scopes, nonce, redirect_uri, claims_user_id, claims_username, claims_email, claims_email_verified, claims_groups, connector_id, connector_data, expiry) FROM stdin;
\.
COPY public.auth_code (id, client_id, scopes, nonce, redirect_uri, claims_user_id, claims_username, claims_email, claims_email_verified, claims_groups, connector_id, connector_data, expiry) FROM '$$PATH$$/2923.dat';

--
-- Data for Name: auth_request; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_request (id, client_id, response_types, scopes, redirect_uri, nonce, state, force_approval_prompt, logged_in, claims_user_id, claims_username, claims_email, claims_email_verified, claims_groups, connector_id, connector_data, expiry) FROM stdin;
\.
COPY public.auth_request (id, client_id, response_types, scopes, redirect_uri, nonce, state, force_approval_prompt, logged_in, claims_user_id, claims_username, claims_email, claims_email_verified, claims_groups, connector_id, connector_data, expiry) FROM '$$PATH$$/2922.dat';

--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client (id, secret, redirect_uris, trusted_peers, public, name, logo_url) FROM stdin;
\.
COPY public.client (id, secret, redirect_uris, trusted_peers, public, name, logo_url) FROM '$$PATH$$/2921.dat';

--
-- Data for Name: connector; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.connector (id, type, name, resource_version, config) FROM stdin;
\.
COPY public.connector (id, type, name, resource_version, config) FROM '$$PATH$$/2928.dat';

--
-- Data for Name: keys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.keys (id, verification_keys, signing_key, signing_key_pub, next_rotation) FROM stdin;
\.
COPY public.keys (id, verification_keys, signing_key, signing_key_pub, next_rotation) FROM '$$PATH$$/2926.dat';

--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migrations (num, at) FROM stdin;
\.
COPY public.migrations (num, at) FROM '$$PATH$$/2920.dat';

--
-- Data for Name: offline_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.offline_session (user_id, conn_id, refresh) FROM stdin;
\.
COPY public.offline_session (user_id, conn_id, refresh) FROM '$$PATH$$/2927.dat';

--
-- Data for Name: password; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password (email, hash, username, user_id) FROM stdin;
\.
COPY public.password (email, hash, username, user_id) FROM '$$PATH$$/2925.dat';

--
-- Data for Name: refresh_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.refresh_token (id, client_id, scopes, nonce, claims_user_id, claims_username, claims_email, claims_email_verified, claims_groups, connector_id, connector_data, token, created_at, last_used) FROM stdin;
\.
COPY public.refresh_token (id, client_id, scopes, nonce, claims_user_id, claims_username, claims_email, claims_email_verified, claims_groups, connector_id, connector_data, token, created_at, last_used) FROM '$$PATH$$/2924.dat';

--
-- PostgreSQL database dump complete
--

