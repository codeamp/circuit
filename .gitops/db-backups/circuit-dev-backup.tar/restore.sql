--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.4
-- Dumped by pg_dump version 11.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE codeamp;
--
-- Name: codeamp; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE codeamp WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE codeamp OWNER TO postgres;

\connect codeamp

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: hstore; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS hstore WITH SCHEMA public;


--
-- Name: EXTENSION hstore; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION hstore IS 'data type for storing sets of (key, value) pairs';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: environments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.environments (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    name text,
    key text,
    is_default boolean,
    color text
);


ALTER TABLE public.environments OWNER TO postgres;

--
-- Name: extensions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.extensions (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    type text,
    key text,
    name text,
    component text,
    cacheable boolean,
    environment_id uuid,
    config jsonb NOT NULL
);


ALTER TABLE public.extensions OWNER TO postgres;

--
-- Name: features; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.features (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    project_id uuid,
    message text,
    "user" text,
    hash text,
    parent_hash text,
    ref text,
    created timestamp with time zone
);


ALTER TABLE public.features OWNER TO postgres;

--
-- Name: migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migrations (
    id character varying(255) NOT NULL
);


ALTER TABLE public.migrations OWNER TO postgres;

--
-- Name: project_bookmarks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_bookmarks (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    user_id uuid,
    project_id uuid
);


ALTER TABLE public.project_bookmarks OWNER TO postgres;

--
-- Name: project_environments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_environments (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    environment_id uuid,
    project_id uuid
);


ALTER TABLE public.project_environments OWNER TO postgres;

--
-- Name: project_extensions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_extensions (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    project_id uuid,
    extension_id uuid,
    state text,
    state_message text,
    artifacts jsonb,
    config jsonb NOT NULL,
    custom_config jsonb NOT NULL,
    environment_id uuid
);


ALTER TABLE public.project_extensions OWNER TO postgres;

--
-- Name: project_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project_settings (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    environment_id uuid,
    project_id uuid,
    git_branch text,
    continuous_deploy boolean
);


ALTER TABLE public.project_settings OWNER TO postgres;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projects (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    name text,
    slug text,
    repository text,
    secret text,
    git_url text,
    git_protocol text,
    rsa_private_key text,
    rsa_public_key text
);


ALTER TABLE public.projects OWNER TO postgres;

--
-- Name: release_extensions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.release_extensions (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    release_id uuid,
    feature_hash text,
    services_signature text,
    secrets_signature text,
    project_extension_id uuid,
    state text,
    state_message text,
    type text,
    artifacts jsonb,
    finished timestamp with time zone,
    started timestamp with time zone
);


ALTER TABLE public.release_extensions OWNER TO postgres;

--
-- Name: releases; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.releases (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    state text,
    state_message text,
    project_id uuid,
    user_id uuid,
    head_feature_id uuid,
    tail_feature_id uuid,
    services jsonb,
    secrets jsonb,
    project_extensions jsonb,
    environment_id uuid,
    started timestamp with time zone,
    finished timestamp with time zone,
    force_rebuild boolean,
    is_rollback boolean
);


ALTER TABLE public.releases OWNER TO postgres;

--
-- Name: secret_values; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.secret_values (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    secret_id uuid,
    value text,
    user_id uuid
);


ALTER TABLE public.secret_values OWNER TO postgres;

--
-- Name: secrets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.secrets (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    key text,
    type text,
    project_id uuid,
    scope text,
    environment_id uuid,
    is_secret boolean
);


ALTER TABLE public.secrets OWNER TO postgres;

--
-- Name: service_deployment_strategies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_deployment_strategies (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    service_id uuid,
    type text,
    max_unavailable integer,
    max_surge integer
);


ALTER TABLE public.service_deployment_strategies OWNER TO postgres;

--
-- Name: service_health_probe_http_headers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_health_probe_http_headers (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    health_probe_id uuid,
    name text,
    value text
);


ALTER TABLE public.service_health_probe_http_headers OWNER TO postgres;

--
-- Name: service_health_probes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_health_probes (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    service_id uuid,
    type text,
    method text,
    command text,
    port integer,
    scheme text,
    path text,
    initial_delay_seconds integer,
    period_seconds integer,
    timeout_seconds integer,
    success_threshold integer,
    failure_threshold integer
);


ALTER TABLE public.service_health_probes OWNER TO postgres;

--
-- Name: service_ports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_ports (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    service_id uuid,
    protocol text,
    port integer
);


ALTER TABLE public.service_ports OWNER TO postgres;

--
-- Name: service_specs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_specs (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    name text,
    cpu_request text,
    cpu_limit text,
    memory_request text,
    memory_limit text,
    termination_grace_period text,
    service_id uuid,
    is_default boolean
);


ALTER TABLE public.service_specs OWNER TO postgres;

--
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    project_id uuid,
    command text,
    name text,
    type text,
    count integer,
    environment_id uuid,
    pre_stop_hook text
);


ALTER TABLE public.services OWNER TO postgres;

--
-- Name: user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_permissions (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    user_id uuid,
    value text
);


ALTER TABLE public.user_permissions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT public.gen_random_uuid() NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    email text,
    password character varying(255)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: environments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.environments (id, created_at, updated_at, deleted_at, name, key, is_default, color) FROM stdin;
\.
COPY public.environments (id, created_at, updated_at, deleted_at, name, key, is_default, color) FROM '$$PATH$$/3177.dat';

--
-- Data for Name: extensions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.extensions (id, created_at, updated_at, deleted_at, type, key, name, component, cacheable, environment_id, config) FROM stdin;
\.
COPY public.extensions (id, created_at, updated_at, deleted_at, type, key, name, component, cacheable, environment_id, config) FROM '$$PATH$$/3176.dat';

--
-- Data for Name: features; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.features (id, created_at, updated_at, deleted_at, project_id, message, "user", hash, parent_hash, ref, created) FROM stdin;
\.
COPY public.features (id, created_at, updated_at, deleted_at, project_id, message, "user", hash, parent_hash, ref, created) FROM '$$PATH$$/3178.dat';

--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migrations (id) FROM stdin;
\.
COPY public.migrations (id) FROM '$$PATH$$/3179.dat';

--
-- Data for Name: project_bookmarks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_bookmarks (id, created_at, updated_at, deleted_at, user_id, project_id) FROM stdin;
\.
COPY public.project_bookmarks (id, created_at, updated_at, deleted_at, user_id, project_id) FROM '$$PATH$$/3180.dat';

--
-- Data for Name: project_environments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_environments (id, created_at, updated_at, deleted_at, environment_id, project_id) FROM stdin;
\.
COPY public.project_environments (id, created_at, updated_at, deleted_at, environment_id, project_id) FROM '$$PATH$$/3181.dat';

--
-- Data for Name: project_extensions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_extensions (id, created_at, updated_at, deleted_at, project_id, extension_id, state, state_message, artifacts, config, custom_config, environment_id) FROM stdin;
\.
COPY public.project_extensions (id, created_at, updated_at, deleted_at, project_id, extension_id, state, state_message, artifacts, config, custom_config, environment_id) FROM '$$PATH$$/3182.dat';

--
-- Data for Name: project_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project_settings (id, created_at, updated_at, deleted_at, environment_id, project_id, git_branch, continuous_deploy) FROM stdin;
\.
COPY public.project_settings (id, created_at, updated_at, deleted_at, environment_id, project_id, git_branch, continuous_deploy) FROM '$$PATH$$/3184.dat';

--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projects (id, created_at, updated_at, deleted_at, name, slug, repository, secret, git_url, git_protocol, rsa_private_key, rsa_public_key) FROM stdin;
\.
COPY public.projects (id, created_at, updated_at, deleted_at, name, slug, repository, secret, git_url, git_protocol, rsa_private_key, rsa_public_key) FROM '$$PATH$$/3183.dat';

--
-- Data for Name: release_extensions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.release_extensions (id, created_at, updated_at, deleted_at, release_id, feature_hash, services_signature, secrets_signature, project_extension_id, state, state_message, type, artifacts, finished, started) FROM stdin;
\.
COPY public.release_extensions (id, created_at, updated_at, deleted_at, release_id, feature_hash, services_signature, secrets_signature, project_extension_id, state, state_message, type, artifacts, finished, started) FROM '$$PATH$$/3185.dat';

--
-- Data for Name: releases; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.releases (id, created_at, updated_at, deleted_at, state, state_message, project_id, user_id, head_feature_id, tail_feature_id, services, secrets, project_extensions, environment_id, started, finished, force_rebuild, is_rollback) FROM stdin;
\.
COPY public.releases (id, created_at, updated_at, deleted_at, state, state_message, project_id, user_id, head_feature_id, tail_feature_id, services, secrets, project_extensions, environment_id, started, finished, force_rebuild, is_rollback) FROM '$$PATH$$/3186.dat';

--
-- Data for Name: secret_values; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.secret_values (id, created_at, updated_at, deleted_at, secret_id, value, user_id) FROM stdin;
\.
COPY public.secret_values (id, created_at, updated_at, deleted_at, secret_id, value, user_id) FROM '$$PATH$$/3187.dat';

--
-- Data for Name: secrets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.secrets (id, created_at, updated_at, deleted_at, key, type, project_id, scope, environment_id, is_secret) FROM stdin;
\.
COPY public.secrets (id, created_at, updated_at, deleted_at, key, type, project_id, scope, environment_id, is_secret) FROM '$$PATH$$/3188.dat';

--
-- Data for Name: service_deployment_strategies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_deployment_strategies (id, created_at, updated_at, deleted_at, service_id, type, max_unavailable, max_surge) FROM stdin;
\.
COPY public.service_deployment_strategies (id, created_at, updated_at, deleted_at, service_id, type, max_unavailable, max_surge) FROM '$$PATH$$/3189.dat';

--
-- Data for Name: service_health_probe_http_headers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_health_probe_http_headers (id, created_at, updated_at, deleted_at, health_probe_id, name, value) FROM stdin;
\.
COPY public.service_health_probe_http_headers (id, created_at, updated_at, deleted_at, health_probe_id, name, value) FROM '$$PATH$$/3190.dat';

--
-- Data for Name: service_health_probes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_health_probes (id, created_at, updated_at, deleted_at, service_id, type, method, command, port, scheme, path, initial_delay_seconds, period_seconds, timeout_seconds, success_threshold, failure_threshold) FROM stdin;
\.
COPY public.service_health_probes (id, created_at, updated_at, deleted_at, service_id, type, method, command, port, scheme, path, initial_delay_seconds, period_seconds, timeout_seconds, success_threshold, failure_threshold) FROM '$$PATH$$/3191.dat';

--
-- Data for Name: service_ports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_ports (id, created_at, updated_at, deleted_at, service_id, protocol, port) FROM stdin;
\.
COPY public.service_ports (id, created_at, updated_at, deleted_at, service_id, protocol, port) FROM '$$PATH$$/3192.dat';

--
-- Data for Name: service_specs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_specs (id, created_at, updated_at, deleted_at, name, cpu_request, cpu_limit, memory_request, memory_limit, termination_grace_period, service_id, is_default) FROM stdin;
\.
COPY public.service_specs (id, created_at, updated_at, deleted_at, name, cpu_request, cpu_limit, memory_request, memory_limit, termination_grace_period, service_id, is_default) FROM '$$PATH$$/3193.dat';

--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.services (id, created_at, updated_at, deleted_at, project_id, command, name, type, count, environment_id, pre_stop_hook) FROM stdin;
\.
COPY public.services (id, created_at, updated_at, deleted_at, project_id, command, name, type, count, environment_id, pre_stop_hook) FROM '$$PATH$$/3194.dat';

--
-- Data for Name: user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_permissions (id, created_at, updated_at, deleted_at, user_id, value) FROM stdin;
\.
COPY public.user_permissions (id, created_at, updated_at, deleted_at, user_id, value) FROM '$$PATH$$/3195.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, created_at, updated_at, deleted_at, email, password) FROM stdin;
\.
COPY public.users (id, created_at, updated_at, deleted_at, email, password) FROM '$$PATH$$/3175.dat';

--
-- Name: environments environments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.environments
    ADD CONSTRAINT environments_pkey PRIMARY KEY (id);


--
-- Name: extensions extensions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.extensions
    ADD CONSTRAINT extensions_pkey PRIMARY KEY (id);


--
-- Name: features features_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.features
    ADD CONSTRAINT features_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: project_bookmarks project_bookmarks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_bookmarks
    ADD CONSTRAINT project_bookmarks_pkey PRIMARY KEY (id);


--
-- Name: project_environments project_environments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_environments
    ADD CONSTRAINT project_environments_pkey PRIMARY KEY (id);


--
-- Name: project_extensions project_extensions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_extensions
    ADD CONSTRAINT project_extensions_pkey PRIMARY KEY (id);


--
-- Name: project_settings project_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project_settings
    ADD CONSTRAINT project_settings_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: release_extensions release_extensions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.release_extensions
    ADD CONSTRAINT release_extensions_pkey PRIMARY KEY (id);


--
-- Name: releases releases_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.releases
    ADD CONSTRAINT releases_pkey PRIMARY KEY (id);


--
-- Name: secret_values secret_values_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.secret_values
    ADD CONSTRAINT secret_values_pkey PRIMARY KEY (id);


--
-- Name: secrets secrets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.secrets
    ADD CONSTRAINT secrets_pkey PRIMARY KEY (id);


--
-- Name: service_deployment_strategies service_deployment_strategies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_deployment_strategies
    ADD CONSTRAINT service_deployment_strategies_pkey PRIMARY KEY (id);


--
-- Name: service_health_probe_http_headers service_health_probe_http_headers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_health_probe_http_headers
    ADD CONSTRAINT service_health_probe_http_headers_pkey PRIMARY KEY (id);


--
-- Name: service_health_probes service_health_probes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_health_probes
    ADD CONSTRAINT service_health_probes_pkey PRIMARY KEY (id);


--
-- Name: service_ports service_ports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_ports
    ADD CONSTRAINT service_ports_pkey PRIMARY KEY (id);


--
-- Name: service_specs service_specs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_specs
    ADD CONSTRAINT service_specs_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: user_permissions user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_environments_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_environments_deleted_at ON public.environments USING btree (deleted_at);


--
-- Name: idx_extensions_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_extensions_deleted_at ON public.extensions USING btree (deleted_at);


--
-- Name: idx_features_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_features_deleted_at ON public.features USING btree (deleted_at);


--
-- Name: idx_project_bookmarks_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_project_bookmarks_deleted_at ON public.project_bookmarks USING btree (deleted_at);


--
-- Name: idx_project_environments_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_project_environments_deleted_at ON public.project_environments USING btree (deleted_at);


--
-- Name: idx_project_extensions_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_project_extensions_deleted_at ON public.project_extensions USING btree (deleted_at);


--
-- Name: idx_project_settings_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_project_settings_deleted_at ON public.project_settings USING btree (deleted_at);


--
-- Name: idx_projects_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_projects_deleted_at ON public.projects USING btree (deleted_at);


--
-- Name: idx_release_extensions_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_release_extensions_deleted_at ON public.release_extensions USING btree (deleted_at);


--
-- Name: idx_releases_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_releases_deleted_at ON public.releases USING btree (deleted_at);


--
-- Name: idx_secret_values_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_secret_values_deleted_at ON public.secret_values USING btree (deleted_at);


--
-- Name: idx_secrets_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_secrets_deleted_at ON public.secrets USING btree (deleted_at);


--
-- Name: idx_service_deployment_strategies_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_service_deployment_strategies_deleted_at ON public.service_deployment_strategies USING btree (deleted_at);


--
-- Name: idx_service_health_probe_http_headers_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_service_health_probe_http_headers_deleted_at ON public.service_health_probe_http_headers USING btree (deleted_at);


--
-- Name: idx_service_health_probes_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_service_health_probes_deleted_at ON public.service_health_probes USING btree (deleted_at);


--
-- Name: idx_service_ports_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_service_ports_deleted_at ON public.service_ports USING btree (deleted_at);


--
-- Name: idx_service_specs_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_service_specs_deleted_at ON public.service_specs USING btree (deleted_at);


--
-- Name: idx_services_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_services_deleted_at ON public.services USING btree (deleted_at);


--
-- Name: idx_user_permissions_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_permissions_deleted_at ON public.user_permissions USING btree (deleted_at);


--
-- Name: idx_users_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_deleted_at ON public.users USING btree (deleted_at);


--
-- Name: DATABASE codeamp; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE codeamp TO codeamp;


--
-- PostgreSQL database dump complete
--

